# HACKERNEWS — 2026-03-28
_Fetched: 2026-03-28T08:10:58.917150+00:00_
_Items: 17_

---

## 1. Go hard on agents, not on your filesystem
- **URL**: https://jai.scs.stanford.edu/
- **Source**: hackernews
- **Published**: 2026-03-28T00:39:54+00:00
- **Points**: 287
- **Comments**: 153
- **By**: mazieres
- **Hn_id**: 47550282

**Points:** 287 | **Comments:** 153
**Discussion:** https://news.ycombinator.com/item?id=47550282
_mazieres posted this story_

---

## 2. AMD's Ryzen 9 9950X3D2 Dual Edition crams 208MB of cache into a single chip
- **URL**: https://arstechnica.com/gadgets/2026/03/amds-ryzen-9-9950x3d2-dual-edition-crams-208mb-of-cache-into-a-single-chip/
- **Source**: hackernews
- **Published**: 2026-03-28T02:17:04+00:00
- **Points**: 131
- **Comments**: 62
- **By**: zdw
- **Hn_id**: 47550878

**Points:** 131 | **Comments:** 62
**Discussion:** https://news.ycombinator.com/item?id=47550878
_zdw posted this story_

---

## 3. Make macOS consistently bad unironically
- **URL**: https://lr0.org/blog/p/macos/
- **Source**: hackernews
- **Published**: 2026-03-27T19:15:19+00:00
- **Points**: 383
- **Comments**: 262
- **By**: speckx
- **Hn_id**: 47547009

**Points:** 383 | **Comments:** 262
**Discussion:** https://news.ycombinator.com/item?id=47547009
_speckx posted this story_

---

## 4. Anatomy of the .claude/ folder
- **URL**: https://blog.dailydoseofds.com/p/anatomy-of-the-claude-folder
- **Source**: hackernews
- **Published**: 2026-03-27T14:35:45+00:00
- **Points**: 471
- **Comments**: 217
- **By**: freedomben
- **Hn_id**: 47543139

**Points:** 471 | **Comments:** 217
**Discussion:** https://news.ycombinator.com/item?id=47543139
_freedomben posted this story_

---

## 5. Velxio 2.0 – Emulate Arduino, ESP32, and Raspberry Pi 3 in the Browser
- **URL**: https://github.com/davidmonterocrespo24/velxio
- **Source**: hackernews
- **Published**: 2026-03-27T20:44:33+00:00
- **Points**: 136
- **Comments**: 43
- **By**: dmcrespo
- **Hn_id**: 47548013

**Points:** 136 | **Comments:** 43
**Discussion:** https://news.ycombinator.com/item?id=47548013
_dmcrespo posted this story_

---

## 6. Show HN: Twitch Roulette – Find live streamers who need views the most
- **URL**: https://twitchroulette.net/
- **Source**: hackernews
- **Published**: 2026-03-27T22:22:20+00:00
- **Points**: 102
- **Comments**: 50
- **By**: ellg
- **Hn_id**: 47549160

**Points:** 102 | **Comments:** 50
**Discussion:** https://news.ycombinator.com/item?id=47549160
_ellg posted this story_

---

## 7. ISBN Visualization
- **URL**: https://annas-archive.gd/isbn-visualization?
- **Source**: hackernews
- **Published**: 2026-03-27T20:02:05+00:00
- **Points**: 152
- **Comments**: 23
- **By**: Cider9986
- **Hn_id**: 47547508

**Points:** 152 | **Comments:** 23
**Discussion:** https://news.ycombinator.com/item?id=47547508
_Cider9986 posted this story_

---

## 8. ‘Energy independence feels practical’: Europeans building mini solar farms
- **URL**: https://www.euronews.com/2026/03/26/suddenly-energy-independence-feels-practical-europeans-are-building-mini-solar-farms-at-ho
- **Source**: hackernews
- **Published**: 2026-03-27T08:55:43+00:00
- **Points**: 270
- **Comments**: 255
- **By**: vrganj
- **Hn_id**: 47540383

**Points:** 270 | **Comments:** 255
**Discussion:** https://news.ycombinator.com/item?id=47540383
_vrganj posted this story_

---

## 9. Meow.camera
- **URL**: https://meow.camera/#4258783365322591678
- **Source**: hackernews
- **Published**: 2026-03-27T14:41:02+00:00
- **Points**: 249
- **Comments**: 59
- **By**: surprisetalk
- **Hn_id**: 47543204

**Points:** 249 | **Comments:** 59
**Discussion:** https://news.ycombinator.com/item?id=47543204
_surprisetalk posted this story_

---

## 10. Installing a Let's Encrypt TLS certificate on a Brother printer with Certbot
- **URL**: https://owltec.ca/Other/Installing+a+Let%27s+Encrypt+TLS+certificate+on+a+Brother+printer+automatically+with+Certbot+(%26+Cloudflare)
- **Source**: hackernews
- **Published**: 2026-03-27T13:49:51+00:00
- **Points**: 212
- **Comments**: 52
- **By**: 8organicbits
- **Hn_id**: 47542644

**Points:** 212 | **Comments:** 52
**Discussion:** https://news.ycombinator.com/item?id=47542644
_8organicbits posted this story_

---

## 11. Iran-linked hackers breach FBI director's personal email
- **URL**: https://www.reuters.com/world/us/iran-linked-hackers-claim-breach-of-fbi-directors-personal-email-doj-official-2026-03-27/
- **Source**: hackernews
- **Published**: 2026-03-27T14:38:28+00:00
- **Points**: 231
- **Comments**: 334
- **By**: m-hodges
- **Hn_id**: 47543167

**Points:** 231 | **Comments:** 334
**Discussion:** https://news.ycombinator.com/item?id=47543167
_m-hodges posted this story_

---

## 12. People inside Microsoft are fighting to drop mandatory Microsoft Account
- **URL**: https://www.windowscentral.com/microsoft/windows-11/people-inside-microsoft-are-fighting-to-drop-windows-11s-mandatory-microsoft-account-requirements-during-setup
- **Source**: hackernews
- **Published**: 2026-03-27T13:54:35+00:00
- **Points**: 618
- **Comments**: 460
- **By**: breve
- **Hn_id**: 47542695

**Points:** 618 | **Comments:** 460
**Discussion:** https://news.ycombinator.com/item?id=47542695
_breve posted this story_

---

## 13. Desk for people who work at home with a cat
- **URL**: https://soranews24.com/2026/03/27/japan-now-has-a-special-desk-for-people-who-work-at-home-with-a-pet-catphotos/
- **Source**: hackernews
- **Published**: 2026-03-27T15:31:20+00:00
- **Points**: 396
- **Comments**: 141
- **By**: zdw
- **Hn_id**: 47543943

**Points:** 396 | **Comments:** 141
**Discussion:** https://news.ycombinator.com/item?id=47543943
_zdw posted this story_

---

## 14. Colorado House passes bill to limit surveillance pricing and wage setting
- **URL**: https://coloradonewsline.com/briefs/surveillance-pricing-wage-setting/
- **Source**: hackernews
- **Published**: 2026-03-27T20:10:42+00:00
- **Points**: 101
- **Comments**: 26
- **By**: jprs
- **Hn_id**: 47547602

**Points:** 101 | **Comments:** 26
**Discussion:** https://news.ycombinator.com/item?id=47547602
_jprs posted this story_

---

## 15. Hold on to Your Hardware
- **URL**: https://xn--gckvb8fzb.com/hold-on-to-your-hardware/
- **Source**: hackernews
- **Published**: 2026-03-27T10:10:41+00:00
- **Points**: 608
- **Comments**: 481
- **By**: LucidLynx
- **Hn_id**: 47540833

**Points:** 608 | **Comments:** 481
**Discussion:** https://news.ycombinator.com/item?id=47540833
_LucidLynx posted this story_

---

## 16. Should QA exist?
- **URL**: https://www.rubick.com/should-qa-exist/
- **Source**: hackernews
- **Published**: 2026-03-27T10:27:28+00:00
- **Points**: 120
- **Comments**: 145
- **By**: PretzelFisch
- **Hn_id**: 47540929

**Points:** 120 | **Comments:** 145
**Discussion:** https://news.ycombinator.com/item?id=47540929
_PretzelFisch posted this story_

---

## 17. The 'paperwork flood': How I drowned a bureaucrat before dinner
- **URL**: https://sightlessscribbles.com/posts/the-paperwork-flood/
- **Source**: hackernews
- **Published**: 2026-03-27T12:46:49+00:00
- **Points**: 544
- **Comments**: 442
- **By**: robin_reala
- **Hn_id**: 47542057

**Points:** 544 | **Comments:** 442
**Discussion:** https://news.ycombinator.com/item?id=47542057
_robin_reala posted this story_

---
