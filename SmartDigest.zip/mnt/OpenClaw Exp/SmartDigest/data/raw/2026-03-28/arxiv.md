# ARXIV — 2026-03-28
_Fetched: 2026-03-28T08:11:03.705048+00:00_
_Items: 8_

---

## 1. ShotStream: Streaming Multi-Shot Video Generation for Interactive Storytelling
- **URL**: http://arxiv.org/abs/2603.25746v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:59Z
- **Authors**: Yawen Luo, Xiaoyu Shi, Junhao Zhuang et al.
- **Categories**: cs.CV
- **Pdf**: https://arxiv.org/pdf/2603.25746v1
- **Updated**: 2026-03-26T17:59:59Z
- **Query**: large language model agents tool use

Multi-shot video generation is crucial for long narrative storytelling, yet current bidirectional architectures suffer from limited interactivity and high latency. We propose ShotStream, a novel causal multi-shot architecture that enables interactive storytelling and efficient on-the-fly frame generation. By reformulating the task as next-shot generation conditioned on historical context, ShotStream allows users to dynamically instruct ongoing narratives via streaming prompts. We achieve this by first fine-tuning a text-to-video model into a bidirectional next-shot generator, which is then dis...

---

## 2. Less Gaussians, Texture More: 4K Feed-Forward Textured Splatting
- **URL**: http://arxiv.org/abs/2603.25745v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:59Z
- **Authors**: Yixing Lao, Xuyang Bai, Xiaoyang Wu et al.
- **Categories**: cs.CV
- **Pdf**: https://arxiv.org/pdf/2603.25745v1
- **Updated**: 2026-03-26T17:59:59Z
- **Query**: large language model agents tool use

Existing feed-forward 3D Gaussian Splatting methods predict pixel-aligned primitives, leading to a quadratic growth in primitive count as resolution increases. This fundamentally limits their scalability, making high-resolution synthesis such as 4K intractable. We introduce LGTM (Less Gaussians, Texture More), a feed-forward framework that overcomes this resolution scaling barrier. By predicting compact Gaussian primitives coupled with per-primitive textures, LGTM decouples geometric complexity from rendering resolution. This approach enables high-fidelity 4K novel view synthesis without per-s...

---

## 3. MuRF: Unlocking the Multi-Scale Potential of Vision Foundation Models
- **URL**: http://arxiv.org/abs/2603.25744v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:58Z
- **Authors**: Bocheng Zou, Mu Cai, Mark Stanley et al.
- **Categories**: cs.CV
- **Pdf**: https://arxiv.org/pdf/2603.25744v1
- **Updated**: 2026-03-26T17:59:58Z
- **Query**: large language model agents tool use

Vision Foundation Models (VFMs) have become the cornerstone of modern computer vision, offering robust representations across a wide array of tasks. While recent advances allow these models to handle varying input sizes during training, inference typically remains restricted to a single, fixed scale. This prevalent single-scale paradigm overlooks a fundamental property of visual perception: varying resolutions offer complementary inductive biases, where low-resolution views excel at global semantic recognition and high-resolution views are essential for fine-grained refinement. In this work, w...

---

## 4. RefAlign: Representation Alignment for Reference-to-Video Generation
- **URL**: http://arxiv.org/abs/2603.25743v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:57Z
- **Authors**: Lei Wang, YuXin Song, Ge Wu et al.
- **Categories**: cs.CV
- **Pdf**: https://arxiv.org/pdf/2603.25743v1
- **Updated**: 2026-03-26T17:59:57Z
- **Query**: large language model agents tool use

Reference-to-video (R2V) generation is a controllable video synthesis paradigm that constrains the generation process using both text prompts and reference images, enabling applications such as personalized advertising and virtual try-on. In practice, existing R2V methods typically introduce additional high-level semantic or cross-modal features alongside the VAE latent representation of the reference image and jointly feed them into the diffusion Transformer (DiT). These auxiliary representations provide semantic guidance and act as implicit alignment signals, which can partially alleviate pi...

---

## 5. Pseudogap and Non-Fermi-liquid criticality in double Kondo model for bilayer nickelates
- **URL**: http://arxiv.org/abs/2603.25742v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:56Z
- **Authors**: Jing-Yu Zhao, Ya-Hui Zhang
- **Categories**: cond-mat.str-el
- **Pdf**: https://arxiv.org/pdf/2603.25742v1
- **Updated**: 2026-03-26T17:59:56Z
- **Query**: large language model agents tool use

Motivated by recent experimental progress on high-temperature superconductivity in bilayer nickelates, we investigate the phase diagram of the normal state in a bilayer Kondo lattice model using single-site dynamical mean-field theory (DMFT). When the interlayer tunneling $t_\perp$ is absent, we identify a non-Fermi-liquid (NFL) critical point tuned by the interlayer spin coupling $J_\perp$ or hole doping $x$, which separates a standard Fermi liquid in the overdoped region from a distinct pseudogap (PG) metal in the underdoped regime. This PG phase, which we term the `second Fermi liquid' (sFL...

---

## 6. Vega: Learning to Drive with Natural Language Instructions
- **URL**: http://arxiv.org/abs/2603.25741v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:56Z
- **Authors**: Sicheng Zuo, Yuxuan Li, Wenzhao Zheng et al.
- **Categories**: cs.CV, cs.AI, cs.RO
- **Pdf**: https://arxiv.org/pdf/2603.25741v1
- **Updated**: 2026-03-26T17:59:56Z
- **Query**: large language model agents tool use

Vision-language-action models have reshaped autonomous driving to incorporate languages into the decision-making process. However, most existing pipelines only utilize the language modality for scene descriptions or reasoning and lack the flexibility to follow diverse user instructions for personalized driving. To address this, we first construct a large-scale driving dataset (InstructScene) containing around 100,000 scenes annotated with diverse driving instructions with the corresponding trajectories. We then propose a unified Vision-Language-World-Action model, Vega, for instruction-based g...

---

## 7. Drive My Way: Preference Alignment of Vision-Language-Action Model for Personalized Driving
- **URL**: http://arxiv.org/abs/2603.25740v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:54Z
- **Authors**: Zehao Wang, Huaide Jiang, Shuaiwu Dong et al.
- **Categories**: cs.RO, cs.AI, cs.CV
- **Pdf**: https://arxiv.org/pdf/2603.25740v1
- **Updated**: 2026-03-26T17:59:54Z
- **Query**: large language model agents tool use

Human driving behavior is inherently personal, which is shaped by long-term habits and influenced by short-term intentions. Individuals differ in how they accelerate, brake, merge, yield, and overtake across diverse situations. However, existing end-to-end autonomous driving systems either optimize for generic objectives or rely on fixed driving modes, lacking the ability to adapt to individual preferences or interpret natural language intent. To address this gap, we propose Drive My Way (DMW), a personalized Vision-Language-Action (VLA) driving framework that aligns with users' long-term driv...

---

## 8. PSDesigner: Automated Graphic Design with a Human-Like Creative Workflow
- **URL**: http://arxiv.org/abs/2603.25738v1
- **Source**: arxiv
- **Published**: 2026-03-26T17:59:51Z
- **Authors**: Xincheng Shuai, Song Tang, Yutong Huang et al.
- **Categories**: cs.CV
- **Pdf**: https://arxiv.org/pdf/2603.25738v1
- **Updated**: 2026-03-26T17:59:51Z
- **Query**: large language model agents tool use

Graphic design is a creative and innovative process that plays a crucial role in applications such as e-commerce and advertising. However, developing an automated design system that can faithfully translate user intentions into editable design files remains an open challenge. Although recent studies have leveraged powerful text-to-image models and MLLMs to assist graphic design, they typically simplify professional workflows, resulting in limited flexibility and intuitiveness. To address these limitations, we propose PSDesigner, an automated graphic design system that emulates the creative wor...

---
